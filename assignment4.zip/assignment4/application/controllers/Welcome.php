<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	
	public function index()
	{	
		$this->common('header','footer','welcome_message');
	}

	public function updateProfile(){

			$id = $this->session->userdata('id');
			$data = array(
				'department'=>$this->input->post('department'),
				'subdepartment'=>$this->input->post('subdepartment')
			);
		
				$config['upload_path']  = './upload/';
				$config['allowed_types']  = 'gif|jpg|png|jpeg';
				$config['file_name'] = $_FILES['flimage']['name'];
				$this->load->library('upload', $config);
				$this->upload->initialize($config);

				$data1 =  $this->upload->data();

				if (!empty($_FILES['flimage']['name'])) {
					$data1= array(
						'profile_pic'=>$data1['file_name']
					);
				}

				$merged = array_merge($data, $data1);

				$response = $this->user_model->updateProfile($merged,$id,'user');
				if($response){
					$data['msg'] = "Record Updated Successfully..";
					$data['user'] = $this->user_model->GetData('user');
					$department['department'] = $this->user_model->GetData('department');
					$this->common('header','footer','dashboard', $data);	
				}
	}

	public function dashboard(){
		
		$email = $this->input->post('email');
		$password = $this->input->post('password');
		// set validation rules

		$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[6]');

		if ($this->form_validation->run() === false) {	
			// validation not ok, send validation errors to the view
			$this->common('header','footer','welcome_message');	
		}else{
			$response = $this->user_model->GetusersInfo('user',$password,$email);
			//  echo "<pre>";
			// print_r($response);exit;
			

			if(count($response) > 0){
				$this->session->set_userdata('username', $response[0]['fname']);
				$this->session->set_userdata('id', $response[0]['id']);
				$this->session->set_userdata('email', $response[0]['email']);
				$this->session->set_userdata('logged_in', TRUE);

				$department['department'] = $this->user_model->GetData('department');
				$department['user'] = $this->user_model->GetData('user');
				$this->common('header','footer','dashboard', $department);
			}else{
				$data['msg']= "User Not Exist register first..";
				$this->common('header','footer','signup_form', $data);
			}
			
		}
	}
	public function register(){
		$this->form_validation->set_rules('fname', 'First Name', 'trim|required');
		$this->form_validation->set_rules('lname', 'Last Name', 'trim|required');
		$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[6]');
		if ($this->form_validation->run() === false) {	

			$this->common('header','footer','signup_form');	
		}else{
			$data = array(
				'fname'=>$this->input->post('fname'),
				'lname'=>$this->input->post('lname'),
				'email'=>$this->input->post('email'),
				'password'=>base64_encode($this->input->post('password'))
				//'password'=>password_hash($this->input->post('password'), PASSWORD_BCRYPT)
			);

			$response = $this->user_model->insertData('user',$data);
			if($response){
				$data['msg']= "Record inserted successfully";
				$this->common('header','footer','signup_form', $data);	
			}
		}
	}


	public function GetSubdepartment(){
		$postData = $this->input->post();
		
		$this->db->select('id,subdepartment');
        $this->db->from('subdepartment');
        $this->db->where('department_id', $postData['menu']);
		$query = $this->db->get();
		
		//echo $this->db->last_query();exit;
        $data = $query->result_array();
		echo json_encode($data); 
		//return $response;
	}

	public function logout(){
		
		if (isset($_SESSION)) {
		
			// remove session datas
			foreach ($_SESSION as $key => $value) {
				unset($_SESSION[$key]);
			}
			
			// user logout ok
			$this->common('header','footer','welcome_message');
			
		} else {
			// redirect him to site root
			redirect('/');
		}
		
	}

	public function common($header=null,$footer=null,$view_page=null,$msg=null)
	{
		$this->load->view($header);
		$this->load->view($view_page, $msg);
		$this->load->view($footer);
	}
}
