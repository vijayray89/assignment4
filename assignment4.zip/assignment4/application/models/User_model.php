<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * User_model class.
 * 
 * @extends CI_Model
 */
class User_model extends CI_Model {

    public function insertData($table=null,$data=null){
        $result = $this->db->insert($table, $data);

       // echo $this->db->last_query();exit;
        if($result){
            return true;
        }else{
            return false;
        }
    }

    public function GetusersInfo($table=null,$password=null, $where_column=null){

        $q  = $this->db->select('password,id')->from('user')->where('email',$where_column)->get()->row();
        
             if($q){
                 $hash_password = base64_decode($q->password);
     
            if ($password===$hash_password) {
                $this->db->select('*');
                $this->db->from($table);
                $this->db->where('email', $where_column);
                //echo $this->db->last_query();exit;
                return $this->db->get()->result_array();
               }
             }
        }

        function updateProfile($data, $id, $table)
            {
                $this->db->where('id', $id);

                if ($this->db->update($table, $data))
                
                    return true;
                return false;
            }

        public function GetData($table=null){
            $this->db->select('*');
            $this->db->from($table);

            return $this->db->get()->result_array();
        }
    
}
?>