<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="container">
	<div class="row">
		
		<div class="card">
			<div class="page-header">
				<h1>Update Profile</h1>
				<?php if(isset($msg)) {?>
					<div class="alert"><?= $msg; ?></div>
				<?php } ?>
			</div>
			<?= form_open_multipart('welcome/updateProfile') ?>

				<div class="form-group">					
					<input type="file" class="form-control" id="flimage" name="flimage">
					<?php echo form_error('img', '<div class="error">', '</div>'); ?>
				</div>
				<div class="form-group">
					<label for="department">Department</label>
					<select class="form-control" id="drpmenu" name="department">
                        <option value="">--Select Department--</option>
                        <?php 
                        foreach($department as $row){ ?>
                            <option value="<?= $row['id']?> "><?= $row['department']?> </option>
                      <?php  }
                        
                        ?>
                    </select>
				</div>
                <div class="form-group">
					<label for="subdepartment">Sub Department</label>
					<select class="form-control" id="drpsubmenu" name="subdepartment">
                        <option value="">--Select SubDepartment--</option>
                    </select>
				</div>
				<div class="form-group">
					<input type="submit" class="btn btn-default" value="Submit">
				</div>
			</form>
		</div>


        <div class="card">
            <table class="table">
            <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>profile pic</th>
            <th>department</th>
            <th>subdepartment</th>
            </tr>
                        <?php 
                        foreach($user as $row){
                        ?>
                        <tr>
                            <td><?=$row['fname'];?></td>
                            <td><?= $row['lname'];?></td>
                            <td><?= $row['email'];?></td>
                            <td><?=$row['profile_pic']; ?></td>
                            <td><?= $row['department'];?></td>
                            <td><?= $row['subdepartment'];?></td>
                            
                        </tr>
                      <?php 
                        }
                        ?>
            </table>
        </div>
	</div><!-- .row -->
</div><!-- .container -->
