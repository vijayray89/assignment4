<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
	</main><!-- #site-content -->

	<footer id="site-footer" role="contentinfo">
	</footer><!-- #site-footer -->

	<!-- js -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
	<script src="<?= base_url('assets/js/bootstrap.min.js') ?>"></script>
	<script src="<?= base_url('assets/js/script.js') ?>"></script>
	<script src="//cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>

	<script>
		$(document).ready(function(){
			
			$('#test1').click(function(){
				var url = "<?php echo base_url(); ?>user/getRecords"
				$.ajax({
						type: "POST",
						contentType: "application/json; charset=utf-8",
						url: encodeURI(url), // adjust your path
						success: function (data) {
							$('#fetch1').html(data);
						},
						error: function (data) {
							console.log(data);
						}
					});
				});
				
			//Read json file using ajax and display in paginations	
			
					var url = '<?php echo base_url(); ?>assets/jsonfile/json.json';
					
					
					$.getJSON(url, function(data){ 
						var json_data="";
						
							 $.each(data,function(key, value){
								console.log(value.length);
								 for (var i = 0; i < value.length; i++) {
									 tr = $('<tr/>');
									 tr.append("<td>" + value[i].bankName + "</td>");
									 tr.append("<td>" + value[i].bankAddress + "</td>");
									 tr.append("<td>" + value[i].bankLogo + "</td>");
									 tr.append("<td>" + value[i].bankProcessor + "</td>");
									 $('#myTable tbody').append(tr);
								 }
							
							});
								$('table#myTable').DataTable({
									 "pagingType": "full_numbers"
								 });
							
							
					});
			//json code end Here
			
			 //Geolocation coordinates
			 $('#getLocation').click(function(){
				 var x = document.getElementById("location");

				
				  if (navigator.geolocation) {
					navigator.geolocation.getCurrentPosition(showPosition);
				  } else { 
					x.innerHTML = "Geolocation is not supported by this browser.";
				  }
				

				function showPosition(position) {
				  x.innerHTML = "Latitude: " + position.coords.latitude + 
				  "<br>Longitude: " + position.coords.longitude;
				}
			 });

					// menu change
					$('#drpmenu').change(function(){
						
					var menu = $(this).val();
					
					var url = "<?php echo base_url('index.php/welcome/GetSubdepartment')?>";
					
					$.ajax({
						url:url,
						method: 'POST',
						data: {menu: menu},
						dataType: 'json',
						success: function(response){
						// Remove options 
						
						$('#drpsubmenu').find('option').not(':first').remove();
						
						// Add options
						$.each(response,function(index, result){
							
							$('#drpsubmenu').append('<option value="'+result.subdepartment+'">'+result.subdepartment+'</option>');
						});
						}
					});
				});

			 
			 
		});
	</script>
</body>
</html>