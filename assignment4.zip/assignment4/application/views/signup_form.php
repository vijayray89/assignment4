<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="page-header">
				<h1>Register</h1>
                <?php if(isset($msg)) {?>
					<div class="alert alert-success"><?= $msg; ?></div>
				<?php } ?>
			</div>
			<?= form_open('welcome/register') ?>
				<div class="form-group">
					<label for="username">First Name</label>
					<input type="text" class="form-control" id="fname" name="fname" placeholder="Enter first name..">
					<?php echo form_error('fname','<div class="error">', '</div>');?>
				</div>
                <div class="form-group">
					<label for="username">Last Name</label>
					<input type="text" class="form-control" id="lname" name="lname" placeholder="Enter last name..">
					<?php echo form_error('lname','<div class="error">', '</div>');?>
				</div>
				<div class="form-group">
					<label for="email">Email</label>
					<input type="email" class="form-control" id="email" name="email" placeholder="Enter your email">
					<?php echo form_error('email','<div class="error">', '</div>');?>
				</div>
				<div class="form-group">
					<label for="password">Password</label>
					<input type="password" class="form-control" id="password" name="password" placeholder="Enter a password">
					<?php echo form_error('password','<div class="error">', '</div>');?>
				</div>
				
				<div class="form-group">
					<input type="submit" class="btn btn-default" value="Register">
				</div>
			</form>
		</div>
	</div><!-- .row -->
</div><!-- .container -->