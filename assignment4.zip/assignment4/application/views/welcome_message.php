<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="container">
	<div class="row">
		
		<div class="card">
			<div class="page-header">
				<h1>Login</h1>
				<?php if(isset($msg)) {?>
					<div class="error"><?= $msg; ?></div>
				<?php } ?>
			</div>
			<?= form_open('welcome/dashboard') ?>
				<div class="form-group">
					<label for="username">Email</label>
					<input type="text" class="form-control" id="email" name="email" placeholder="Enter Email..">
					<?php echo form_error('email', '<div class="error">', '</div>'); ?>
				</div>
				<div class="form-group">
					<label for="password">Password</label>
					<input type="password" class="form-control" id="password" name="password" placeholder="Your password">
					<?php echo form_error('password','<div class="error">','</div>'); ?>
				</div>
				<div class="form-group">
					<input type="submit" class="btn btn-default" value="Submit">
				</div>
			</form>
		</div>
	</div><!-- .row -->
</div><!-- .container -->